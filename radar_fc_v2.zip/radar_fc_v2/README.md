# Radar FC — versão 0.2

## O que esta versão faz
- Interface web responsiva para celular e computador.
- Consulta de partidas por data.
- Backend Node.js que protege o token da API (o token não fica no navegador).
- Normaliza nome dos times, campeonato, horário, status e placar.

## Fonte de dados
Esta versão está preparada para football-data.org v4. O plano gratuito oferece cobertura limitada de competições e dados/placares com atraso; placares ao vivo e estatísticas avançadas dependem de planos específicos. Confira a cobertura e os limites antes de usar.

Documentação: https://www.football-data.org/documentation/api
Planos e cobertura: https://www.football-data.org/pricing

## Como executar
1. Instale Node.js 18 ou superior.
2. Crie uma variável de ambiente chamada `FOOTBALL_DATA_TOKEN` com seu token.
3. No terminal, dentro desta pasta, execute:
   `node server.js`
4. Abra `http://localhost:3000`.

No macOS/Linux:
`FOOTBALL_DATA_TOKEN="SEU_TOKEN" node server.js`

No Windows PowerShell:
`$env:FOOTBALL_DATA_TOKEN="SEU_TOKEN"; node server.js`

Não compartilhe seu token publicamente nem o coloque no arquivo HTML. Para publicar na internet, hospede o servidor em uma plataforma que permita configurar variáveis de ambiente.

## Próximas etapas
1. Escolher as competições que terão cobertura.
2. Validar os dados recebidos.
3. Adicionar histórico e estatísticas de desempenho dos times.
4. Criar análises descritivas e explicáveis, sem prometer resultados.

Observação: a API pode não disponibilizar minuto, placar em tempo real ou estatísticas detalhadas em todas as competições.
